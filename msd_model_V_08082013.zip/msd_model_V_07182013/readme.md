Get Repo Initialized at this ponit

